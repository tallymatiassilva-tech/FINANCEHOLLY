import java.io.File

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val releaseSigningVariables = listOf(
    "ANDROID_KEYSTORE_PATH",
    "ANDROID_KEYSTORE_PASSWORD",
    "ANDROID_KEY_ALIAS",
    "ANDROID_KEY_PASSWORD",
)
val releaseSigningValues = releaseSigningVariables.associateWith { System.getenv(it) }

gradle.taskGraph.whenReady {
    if (allTasks.any { it.name.contains("Release") }) {
        val missing = releaseSigningVariables.filter {
            releaseSigningValues[it].isNullOrBlank()
        }
        if (missing.isNotEmpty()) {
            throw GradleException(
                "Release signing is not configured. Set: ${missing.joinToString()}",
            )
        }
        val keystorePath = releaseSigningValues.getValue("ANDROID_KEYSTORE_PATH")!!
        if (!File(keystorePath).isFile) {
            throw GradleException("Keystore not found at ANDROID_KEYSTORE_PATH.")
        }
    }
}

android {
    namespace = "br.org.pirituba.controle_financeiro_igreja"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "br.org.pirituba.controle_financeiro_igreja"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            storeFile = releaseSigningValues["ANDROID_KEYSTORE_PATH"]?.let { file(it) }
            storePassword = releaseSigningValues["ANDROID_KEYSTORE_PASSWORD"]
            keyAlias = releaseSigningValues["ANDROID_KEY_ALIAS"]
            keyPassword = releaseSigningValues["ANDROID_KEY_PASSWORD"]
        }
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
